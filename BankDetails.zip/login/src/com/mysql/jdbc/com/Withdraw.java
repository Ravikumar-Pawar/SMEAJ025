package com.mysql.jdbc.com;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class Withdraw extends JFrame {

	private JPanel contentPane;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Withdraw frame = new Withdraw();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Withdraw() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.DARK_GRAY);
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("Withdraw Amount");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("Arial", Font.BOLD, 20));
		lblNewLabel.setBounds(130, 37, 172, 13);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Enter Amount to Withdraw:");
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setFont(new Font("Arial", Font.BOLD, 18));
		lblNewLabel_1.setBounds(34, 60, 268, 33);
		contentPane.add(lblNewLabel_1);
		
		textField = new JTextField();
		textField.setBounds(34, 103, 156, 33);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("Ok");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
					Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/test","lalli","");
					String username=Form.getAccountName();
					int withdraw=Integer.parseInt(textField.getText());
					
					Statement statement = connection.createStatement();
					String query= "SELECT amount FROM login1 where Username = '"+username+"'";
					ResultSet rs= statement.executeQuery(query);
					rs.next();
					int amount = rs.getInt("amount");
					if(amount>withdraw)
					{
						
				
					 amount=amount-withdraw;
					 JOptionPane.showMessageDialog(null,"WithDrawn Successfully. Available Balance is"+amount);
					 String query1="insert into bank(name,WithDraw,AvailAmount)values('"+username+"','"+withdraw+"','"+amount+"')";
					 String query2= "update login1 set amount='"+amount+"' where Username='"+username+"'";
					 
					 statement.executeUpdate(query1);
					 statement.executeUpdate(query2);
					}
					else
					{
						JOptionPane.showMessageDialog(null,"INVALID AMOUNT. Available Balance is"+amount);
					}
					statement.close();
					connection.close();
					
					 }
				catch(Exception e1)
				{
					System.out.println(e1);
				}
			}
		});
		btnNewButton.setForeground(Color.RED);
		btnNewButton.setFont(new Font("Arial", Font.BOLD, 16));
		btnNewButton.setBounds(241, 102, 108, 33);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Back");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Money money = new Money();
				money.setVisible(true);
			}
		});
		btnNewButton_1.setBackground(Color.YELLOW);
		btnNewButton_1.setForeground(Color.RED);
		btnNewButton_1.setFont(new Font("Arial", Font.BOLD, 17));
		btnNewButton_1.setBounds(241, 190, 108, 33);
		contentPane.add(btnNewButton_1);
	}

}
