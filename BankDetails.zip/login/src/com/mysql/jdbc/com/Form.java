package com.mysql.jdbc.com;

import java.awt.BorderLayout;


import java.sql.*;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.TextField;
import java.awt.Font;
import java.awt.Label;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.DropMode;
import java.awt.Button;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.border.LineBorder;
import javax.swing.JButton;

public class Form extends JFrame {

	private JPanel contentPane;
	private Button button;
	private JTextField textField_1;
	private JTextField textField_2;
	public static String name;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Form frame = new Form();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Form() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(238, 232, 170));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("BANK DETAILS");
		lblNewLabel.setBounds(100, 15, 240, 31);
		lblNewLabel.setFont(new Font("Arial", Font.BOLD, 21));
		contentPane.add(lblNewLabel, BorderLayout.NORTH);
		
		JLabel lblNewLabel_1 = new JLabel("Username");
		lblNewLabel_1.setFont(new Font("Arial", Font.BOLD, 15));
		lblNewLabel_1.setBounds(93, 56,75,20);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Password");
		lblNewLabel_2.setFont(new Font("Arial", Font.BOLD, 15));
		lblNewLabel_2.setBounds(93, 121,75,20);
		contentPane.add(lblNewLabel_2, BorderLayout.CENTER);
		Button button_1 = new Button("Login");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
						
					name = textField_2.getText();
					Class.forName("com.mysql.cj.jdbc.Driver");
					Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/test","lalli","");
					Statement statement = connection.createStatement();
					String query="SELECT * FROM login1 where Username='"+textField_2.getText()+"' and Password='"+textField_1.getText()+"' ";
					ResultSet rs= statement.executeQuery(query);
					if(rs.next())
					{
					JOptionPane.showMessageDialog(null,"Login Successfully");
					
					Money money = new Money();
					money.setVisible(true);
					}
					else
					JOptionPane.showMessageDialog(null,"Incorrect username and password ");
					statement.close();
					connection.close();
				   }
				catch(Exception e1)
				{
					System.out.println(e1);
				}
			}
			});
		
		
		
		button_1.setFont(new Font("Arial", Font.BOLD, 13));
		button_1.setBackground(Color.GREEN);
		button_1.setBounds(98, 205, 70, 31);
		contentPane.add(button_1);
		
		Button button_2 = new Button("New User");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
						 Register register = new Register();
						 register.setVisible(true);
					 	}
		});
		 button_2.setFont(new Font("Arial", Font.BOLD, 12));
	    button_2.setBackground(Color.BLUE);
		button_2.setBounds(237, 205, 103, 31);
		contentPane.add(button_2);
		
		textField_1 = new JTextField();
		textField_1.setBounds(93, 158, 202, 26);
		contentPane.add(textField_1);
		
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(93, 86, 202, 25);
		contentPane.add(textField_2);
	     
		}
	public static String getAccountName() {
		return name;
	}
	
	
}
