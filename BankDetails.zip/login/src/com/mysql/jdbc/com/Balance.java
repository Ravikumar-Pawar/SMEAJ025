package com.mysql.jdbc.com;
 import java.sql.*;
import com.mysql.jdbc.com.Form;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import java.awt.Label;

public class Balance extends JFrame {

	private JPanel contentPane;
	public String amount;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Balance frame = new Balance();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Balance() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/test","lalli","");
			String username=Form.getAccountName();
			
			Statement statement = connection.createStatement();
			String query= "SELECT amount FROM login1 where Username = '"+username+"'";
			ResultSet rs= statement.executeQuery(query);
			rs.next();
			 amount = rs.getString("amount");
			 
			statement.close();
			connection.close();
			
			 }
		catch(Exception e1)
		{
			System.out.println(e1);
		}
	
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.PINK);
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("Check Balance");
		lblNewLabel.setFont(new Font("Arial", Font.BOLD, 20));
		lblNewLabel.setBounds(124, 22, 222, 30);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Your Balance is....");
		lblNewLabel_1.setFont(new Font("Arial", Font.BOLD, 17));
		lblNewLabel_1.setBounds(10, 76, 158, 30);
		contentPane.add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("Back");
		btnNewButton.setBackground(Color.MAGENTA);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Money money = new Money();
				money.setVisible(true);
			}
		});
		btnNewButton.setFont(new Font("Arial", Font.BOLD, 16));
		btnNewButton.setBounds(272, 204, 114, 30);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Home Page");
		btnNewButton_1.setBackground(Color.MAGENTA);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Form form = new Form();
				form.setVisible(true);
			}
		});
		btnNewButton_1.setFont(new Font("Arial", Font.BOLD, 16));
		btnNewButton_1.setBounds(33, 204, 147, 30);
		contentPane.add(btnNewButton_1);
	     
		Label label = new Label(amount);
		label.setFont(new Font("Arial", Font.BOLD, 16));
		label.setBounds(91, 134, 91, 21);
		contentPane.add(label);
		
		
		}
}
