package com.mysql.jdbc.com;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class Money extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Money frame = new Money();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Money() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(221, 160, 221));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("Money Transaction");
		lblNewLabel.setForeground(new Color(0, 206, 209));
		lblNewLabel.setBackground(Color.PINK);
		lblNewLabel.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 22));
		lblNewLabel.setBounds(136, 23, 217, 22);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("Check Balance");
		btnNewButton.setForeground(new Color(255, 69, 0));
		btnNewButton.setBackground(Color.PINK);
		btnNewButton.setFont(new Font("Arial", Font.BOLD, 16));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Balance bal = new Balance();
				bal.setVisible(true);
			}
		});
		btnNewButton.setBounds(139, 77, 162, 34);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Withdraw money");
		btnNewButton_1.setForeground(new Color(255, 69, 0));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Withdraw with = new Withdraw();
				with.setVisible(true);
				
			}
		});
		btnNewButton_1.setBackground(Color.PINK);
		btnNewButton_1.setFont(new Font("Arial", Font.BOLD, 16));
		btnNewButton_1.setBounds(126, 146, 192, 34);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Deposit Money");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Deposit depo = new Deposit();
				depo.setVisible(true);
			}
		});
		btnNewButton_2.setForeground(new Color(255, 69, 0));
		btnNewButton_2.setBackground(Color.PINK);
		btnNewButton_2.setFont(new Font("Arial", Font.BOLD, 16));
		btnNewButton_2.setBounds(139, 209, 162, 27);
		contentPane.add(btnNewButton_2);
	}

}
