package com.mysql.jdbc.com;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.sql.*;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Label;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class Register extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Register frame = new Register();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Register() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(233, 150, 122));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("Registration page");
		lblNewLabel.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 21));
		lblNewLabel.setBounds(103, 10, 230, 28);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("UserName");
		lblNewLabel_1.setFont(new Font("Arial", Font.BOLD, 14));
		lblNewLabel_1.setBounds(37, 67, 85, 13);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Password");
		lblNewLabel_2.setFont(new Font("Arial", Font.BOLD, 14));
		lblNewLabel_2.setBounds(37, 102, 85, 13);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("DOB");
		lblNewLabel_3.setBounds(37, 135, 71, 13);
		lblNewLabel_3.setFont(new Font("Arial", Font.BOLD, 14));
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("PhoneNo");
		lblNewLabel_4.setFont(new Font("Arial", Font.BOLD, 14));
		lblNewLabel_4.setBounds(37, 169, 85, 13);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Address");
		lblNewLabel_5.setFont(new Font("Arial", Font.BOLD, 14));
		lblNewLabel_5.setBounds(37, 199, 71, 13);
		contentPane.add(lblNewLabel_5);
		
		textField_1 = new JTextField();
		textField_1.setBounds(212, 65, 144, 19);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		
		textField_2 = new JTextField();
		textField_2.setBounds(212, 100, 144, 19);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
	
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(212, 133, 144, 19);
		contentPane.add(textField_3);
		
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(212, 167, 144, 19);
		contentPane.add(textField_4);
		
		
		textField_5 = new JTextField();
		textField_5.setColumns(10);
		textField_5.setBounds(212, 199, 144, 19);
		contentPane.add(textField_5);
		
		
		JButton btnNewButton = new JButton("Register");
		btnNewButton.setForeground(new Color(100, 149, 237));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
                try {
						Class.forName("com.mysql.cj.jdbc.Driver");
					Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/test","lalli","");
					Statement statement1 = connection.createStatement();
					String que ="select * from login1";
					PreparedStatement statement = connection.prepareStatement("insert into login1 (Username,Password,DOB,phone,address) values (?,?,?,?,?)");
					
					String a = textField_1.getText();
					String b = textField_2.getText();
					String c = textField_3.getText();
					String d = textField_4.getText();
					String f = textField_5.getText();
					
					statement.setString(1, a);
					statement.setString(2, b);
					statement.setDate(3, java.sql.Date.valueOf(c));
					statement.setLong(4, Long.parseLong(d));
					statement.setString(5, f);
					statement.executeUpdate();
					ResultSet rs= statement1.executeQuery(que);
					if(rs.next())
					{
					JOptionPane.showMessageDialog(null,"Registered successfully");
					Form form = new Form();
					form.setVisible(true);
					}
					statement.close();
					connection.close();
					
					 }
				catch(Exception g)
				{
					System.out.println(g);
				}
			}
			
		});
		btnNewButton.setBackground(Color.RED);
		btnNewButton.setFont(new Font("Arial", Font.BOLD, 16));
		btnNewButton.setBounds(150, 228, 104, 25);
		contentPane.add(btnNewButton);
		}
}
